﻿using UnityEngine;
using System.Collections;

public class GameTags {

    public const string player = "Player";
    public const string side = "Sides";
    public const string bullet = "Bullet";
}
